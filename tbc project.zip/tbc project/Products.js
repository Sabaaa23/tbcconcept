document.addEventListener("DOMContentLoaded", function () {
  const productItems = [
    {
      picture: "./images/digital1.png",
      mainText: "ციფრული",
      description:
        "თიბისი კონცეპტის ციფრული ნაკრები განკუთვნილია მათთვის, ვისთვისაც საბანკო მომსახურებით სარგებლობა ყოველდღიურობის ნაწილია, ვინც აქტიურად მოიხმარს არასაბანკო პროდუქტებსა და შეთავაზებებს და ვისაც ურჩევნია დამოუკიდებლად, პირადი ბანკირის გარეშე მართოს საკუთარი ფინანსები და საბანკო ოპერაციები.",
    },
    {
      picture: "./images/digital2.png",
      mainText: "პრემიუმი",
      description:
        "თიბისი კონცეპტის მომხმარებლებთან ურთიერთობის ერთ-ერთი ფორმატი - პრემიუმ ნაკრები, სხვა საბანკო და არასაბანკო უპირატესობებთან ერთად, პირადი ბანკირის მომსახურებას გულისხმობს. პირადი ბანკირის მთავარი ამოცანა მომხარებლისთვის ცხოვრების გამარტივება და მისთვის უმაღლესი ხარისხის მომსახურების უზრუნველყოფაა",
    },
    {
      picture: "./images/digital3.png",
      mainText: "360",
      description:
        "თიბისი კონცეპტის 360 ნაკრები განკუთვნილია მათთვის, ვისაც სხვა საბანკო და არასაბანკო უპიტარესობებთან ერთად, კიდევ უფრო მეტი ფინანსური ინსტრუმენტი და გაზრდილი შესაძლებლობები ესაჭიროება",
    },
  ];

  const container = document.getElementById("product-container");

  function truncateText(text, wordLimit) {
    const words = text.split(" ");
    if (words.length > wordLimit) {
      return words.slice(0, wordLimit).join(" ") + "...";
    }
    return text;
  }

  productItems.forEach((item) => {
    const productDiv = document.createElement("div");
    productDiv.classList.add("product-item");

    const img = document.createElement("img");
    img.src = item.picture;
    productDiv.appendChild(img);

    const mainText = document.createElement("h2");
    mainText.textContent = item.mainText;
    productDiv.appendChild(mainText);

    const description = document.createElement("p");
    description.textContent = truncateText(item.description, 13);
    productDiv.appendChild(description);

    container.appendChild(productDiv);
  });
});
