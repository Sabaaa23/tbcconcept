document.addEventListener("DOMContentLoaded", function () {
  const rewards = [
    {
      picture: "./images/rewards1.png",
      description:
        "საუკეთესო პერსონალური საბანკო მომსახურება საქართველოში 2024",
      mainText: "The Global Finance",
    },
    {
      picture: "./images/rewards2.png",
      description:
        "საუკეთესო პერსონალური საბანკო მომსახურება საქართველოში 2023",
      mainText: "Euromoney",
    },
    {
      picture: "./images/rewards1.png",
      description:
        "საუკეთესო პერსონალური საბანკო მომსახურება საქართველოში 2022",
      mainText: "The Global Finance",
    },
    {
      picture: "./images/rewards3.png",
      description:
        "საუკეთესო პერსონალური საბანკო მომსახურება საქართველოში 2021",
      mainText: "The Banked & PWM",
    },
  ];

  const container = document.getElementById("rewards");
  const lineSegments = document.querySelectorAll(".line-segment2");

  function createRewardsItems(rewardsToDisplay) {
    container.innerHTML = "";
    rewardsToDisplay.forEach((item) => {
      const rewardsItem = document.createElement("div");
      rewardsItem.classList.add("rewards-item");

      const rewardsContent = document.createElement("div");
      rewardsContent.classList.add("rewards-content");

      const img = document.createElement("img");
      img.src = item.picture;
      img.alt = item.mainText || "rewards Image";
      rewardsContent.appendChild(img);

      const rewardsText = document.createElement("div");
      rewardsText.classList.add("rewards-text");

      if (item.mainText) {
        const p1 = document.createElement("p");
        p1.textContent = item.mainText;
        rewardsText.appendChild(p1);
      }

      rewardsContent.appendChild(rewardsText);
      rewardsItem.appendChild(rewardsContent);

      if (item.description) {
        const description = document.createElement("p");
        description.textContent = item.description;
        description.classList.add("rewards-description");
        rewardsItem.appendChild(description);
      }

      container.appendChild(rewardsItem);
    });
  }

  let startIndex = 0;
  const itemsPerSlide = 3;
  const totalItems = rewards.length;

  function updateSlider() {
    const rewardsToDisplay = rewards.slice(
      startIndex,
      startIndex + itemsPerSlide
    );
    createRewardsItems(rewardsToDisplay);
    updateLine();
  }

  function moveSlide2(step) {
    startIndex += step;

    if (startIndex < 0) {
      startIndex = 0;
    } else if (startIndex >= totalItems - itemsPerSlide) {
      startIndex = totalItems - itemsPerSlide;
    }

    updateSlider();
  }

  function updateLine() {
    let activeIndex;
    if (startIndex < 1) {
      activeIndex = 0;
    } else if (startIndex === 1) {
      activeIndex = 3;
    }

    lineSegments.forEach((segment, index) => {
      segment.classList.toggle("active", index === activeIndex);
    });
  }

  document.getElementById("prev-button").addEventListener("click", function () {
    moveSlide2(-itemsPerSlide);
  });

  document.getElementById("next-button").addEventListener("click", function () {
    moveSlide2(itemsPerSlide);
  });

  let isDragging = false;
  let startX;

  container.addEventListener("mousedown", (e) => {
    isDragging = true;
    startX = e.pageX;
    container.style.cursor = "grabbing";
  });

  container.addEventListener("mouseup", () => {
    isDragging = false;
    container.style.cursor = "grab";
  });

  container.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    const x = e.pageX;
    const walk = (x - startX) * 2;
    startX = x;

    if (walk < 0) {
      moveSlide2(itemsPerSlide);
    } else if (walk > 0) {
      moveSlide2(-itemsPerSlide);
    }
  });

  container.addEventListener("touchstart", (e) => {
    isDragging = true;
    startX = e.touches[0].pageX;
  });

  container.addEventListener("touchend", () => {
    isDragging = false;
  });

  container.addEventListener("touchmove", (e) => {
    if (!isDragging) return;
    const x = e.touches[0].pageX;
    const walk = (x - startX) * 2;
    startX = x;

    if (walk < 0) {
      moveSlide2(itemsPerSlide);
    } else if (walk > 0) {
      moveSlide2(-itemsPerSlide);
    }
  });
  updateSlider();
});
