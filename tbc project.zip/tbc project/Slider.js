const items = [
  {
    picture: "./images/proposes1.jpg",
    mainText: "ჯაზ ფესტივალის შეთავაზებები",
    description: "IVERIA BEACH-დაიბრუნეთ 30%",
    cornerPic: "./images/olloseum.png",
  },
  {
    picture: "./images/proposes2.png",
    mainText: "ავტო",
    mainText2: "თეგეტა მოტორსი",
    description: "თეგეტა მოტორსი-50% ფასდაკლება",
    cornerPic: "./images/tegetamotors.png",
  },
  {
    picture: "./images/proposes3.png",
    mainText: "ავტო",
    mainText2: "ჯაზ ფესტივალის შეთავაზებები",
    mainText3: "თეგეტა მოტორსი",
    description: "თეგეტა მოტორსი-ბათუმი",
    cornerPic: "./images/tegetamotors.png",
  },
  {
    picture: "./images/proposes4.png",
    mainText: "დასვენება",
    mainText2: "ვიზა",
    mainText3: "ჯაზ ფესტივალის შეთავაზებები",
    description: "Le Meridien Batumi-15%-იანი ფასდაკლება",
    cornerPic: "./images/meridien.png",
  },
  {
    picture: "./images/proposes5.png",
    mainText: "დასვენება",
    mainText2: "ვიზა",
    mainText3: "ჯაზ ფესტივალის შეთავაზებები",
    description: "Colosseum Marina Hotel-15%-იანი ფასდაკლება",
    cornerPic: "./images/olloseum.png",
  },
  {
    picture: "./images/proposes6.png",
    mainText: "დასვენება",
    mainText2: "სხვა",
    description: "PULSE-რითრითი რაჭაში",
    cornerPic: "./images/pulse.png",
  },
];

const container = document.getElementById("offers");
const lineSegments = document.querySelectorAll(".line-segment");

function createOfferItems(itemsToDisplay) {
  container.innerHTML = "";
  itemsToDisplay.forEach((item) => {
    const offerItem = document.createElement("div");
    offerItem.classList.add("offer-item");

    const offerContent = document.createElement("div");
    offerContent.classList.add("offer-content");

    const img = document.createElement("img");
    img.src = item.picture;
    img.alt = item.mainText || "Offer Image";
    offerContent.appendChild(img);

    if (item.cornerPic) {
      const cornerPic = document.createElement("img");
      cornerPic.src = item.cornerPic;
      cornerPic.alt = "Corner Image";
      cornerPic.classList.add("corner-pic");
      offerContent.appendChild(cornerPic);
    }

    const offerText = document.createElement("div");
    offerText.classList.add("offer-text");

    if (item.mainText) {
      const p1 = document.createElement("p");
      p1.textContent = item.mainText;
      offerText.appendChild(p1);
    }

    if (item.mainText2) {
      const p2 = document.createElement("p");
      p2.textContent = item.mainText2;
      offerText.appendChild(p2);
    }

    if (item.mainText3) {
      const p3 = document.createElement("p");
      p3.textContent = item.mainText3;
      offerText.appendChild(p3);
    }

    offerContent.appendChild(offerText);
    offerItem.appendChild(offerContent);

    if (item.description) {
      const description = document.createElement("p");
      description.textContent = item.description;
      description.classList.add("offer-description");
      offerItem.appendChild(description);
    }

    container.appendChild(offerItem);
  });
}

let startIndex = 0;
const itemsPerSlide = 3;
const totalItems = items.length;
const totalSlides = Math.ceil(totalItems / itemsPerSlide);

function updateSlider() {
  const itemsToDisplay = items.slice(startIndex, startIndex + itemsPerSlide);
  createOfferItems(itemsToDisplay);
  updateLine();
}

function moveSlide(step) {
  startIndex += step;

  if (startIndex < 0) {
    startIndex = 0;
  } else if (startIndex >= totalItems - itemsPerSlide) {
    startIndex = totalItems - itemsPerSlide;
  }

  updateSlider();
}
function updateLine() {
  let activeIndex;
  if (startIndex < 1) {
    activeIndex = 0;
  } else if (startIndex === 1) {
    activeIndex = 1;
  } else if (startIndex === 2) {
    activeIndex = 2;
  } else if (startIndex >= 3) {
    activeIndex = 3;
  }

  lineSegments.forEach((segment, index) => {
    segment.classList.toggle("active", index === activeIndex);
  });
}
updateSlider();
